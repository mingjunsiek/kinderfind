package com.example.kinderfind.adapters;

public interface FirebaseSuccessListener {
    //this is to listen for kindergarten data
    void onKindergartenDataCompleted(boolean isDataCompleted);
}
